import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';


function ORGEditProfile() {


    const apiKey = import.meta.env.VITE_BASE_URL;
    const {id} = useParams();
    const navigate = useNavigate();
  
    // State variables
    const [selectedImage, setSelectedImage] = useState('');
    const [username, setUserName] = useState();
    const [email, setEmail] = useState();

    const [phoneNo, setPhoneNo] = useState();
    const [organizationName, setOrganizationName] = useState();
    const [organizationType, setOrganizationType] = useState();
    const [address, setAddress] = useState();
    const [additionalInfo , setAdditionalInfo] = useState();
    const [imageShow, setimageShow] = useState();
  
    // Function to handle file upload
    const handleUpload = (event) => {
      const file = event.target.files[0];
      if (file) {
          setSelectedImage(file);
          // console.log(file);
      }

      console.log(event.target.files[0]);
  };


    useEffect(() => {
      const getUserById = async (id) => {
        try {
          const result = await axios.get(`${apiKey}/organizers/${id}`);
          const  data  = result.data.organizer;

          console.log(data);
  
  
          setUserName(data.username);
          setEmail(data.email);
          setPhoneNo(data.phoneNo);
          setOrganizationName(data.organizationName);
          setOrganizationType(data.organizationType);
          setAddress(data.address);
          setAdditionalInfo(data.additionalInfo)

          setimageShow(data.image)

          setSelectedImage(data.image); // Assuming you have an 'image' field in your data
        } catch (err) {
          console.log(err);
        }
      };
  
      getUserById(id);
    }, [apiKey, id]);
  
  
  
  const updateData = async(data) => {

    try {
      const formData = new FormData();
      
      formData.append('image', data.selectedImage);
      formData.append('username', data.username);
      formData.append('email', data.email);
      formData.append('organizationName', data.organizationName);
      formData.append('organizationType', data.organizationType);
      formData.append('address', data.address);
      formData.append('additionalInfo', data.additionalInfo);
      formData.append('phoneNo', data.phoneNo);
      
      const response = await axios.post(`${apiKey}/updateOrganizerById/${id}`, formData );
      
      if(response){
        navigate(`/org/profile/${id}`)
      }
      
      console.log(formData);
      console.log('Image uploaded successfully:', response.data.image);
    } catch (error) {
      console.error('Error uploading image:', error);
    }

  }
  
  
    const onSubmit =  (e) => {
  
      e.preventDefault();
  
      let data = {
        username,
        email,
      
        phoneNo,

        organizationName,
        organizationType,
        address,
        additionalInfo,
        selectedImage ,

      };
  
      if(data){
        updateData(data)
      }
  
      
    };
  

    
  return (
    <div class='card p-3'>
    <div class="space-y-4">
      

    <div class="flex flex-row space-x-4 w-full">
      <div className='flex justify-between align-center w-1/2 '>
        <div className="flex justify-center">
          {/* Selected Image Displayed in Circle */}
          <div className="w-28 h-28 overflow-hidden rounded-full border border-gray-300 flex justify-center items-center">
            {imageShow ? (
              <img src={imageShow} alt="Selected" className="object-cover w-full h-full" />
            ) : (
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAzAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABgcBBAUDAv/EADwQAAIBAwEDCAcGBQUAAAAAAAABAgMEBREGITESFkFRU2GS0RMiQnGBkcEHFGKiseEjMlJyoRUkM3Pw/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwC8QAAAAAAAAAAAI3tLtVQxOtvbpV7z+n2Ye/yAkFWtToU3Ur1I04LjKckkjhXm2WHtm4xrSryXZR1XzK4yWUvcnVc724nUeu6GukV7lwNMCwpfaDZrXk2Vw170etvt5jqjXpaNxSXXyVL9CuAFXHj81j8g9LS6pzlp/I3pL5M6KKMTcWnFtNPXVPQk+A2yu7CUKN/KdzbLc5S3zivf0hFmA8LK6o3tvG4tqiqU571JHuAAAAAAAAAAAAAAAAAAAAA8ritC3oVK1RpQhFyb7kBH9sdoP9JtvQWsl98qr1fwR/q9/UVlKUpycpycpSerb4tm1lb+rk8hWu6r3zfqrqj0I0wAACgAAAADtbMZ6rhbxcpuVpN/xafV+Jd5a9GpCrShUpyUoTScZJ8UUd0FgfZ3lHWtqmOrS1lR9alv9l8V8AiaALgAAAAAAAAAAAAAAAAABHNvLp22Aqwi9JV5Kn8OkkZC/tMlpZWUd+jrN/lYFfgAKAAAAAAAAHX2Tu3Z7QWkt+k5ejl7n+5yD3sZOF/ayjxVaD/MgLtBhcEZCAAAAAAAAAAAAAAAABEftIoupiKFVLdSrpv4polxztoLFZHEXNtprKUNY/3LegKcBmScZOMlo1u07zAUAAAAAAAAN3C0XcZeypJca0Pknr9DSJV9nth94y07uUdYW8dz/EwLKAAQAAAAAAAAAAAAAAAAMaGQBWm3WE+4XrvqEP8Ab3EvW09if7kWLtu7ejeUKltcQU6c1pKL6ir9pNm7jDVZVKcZVbNv1Ki9nukBwgAFAAAAPShRq3NaFGhTlUqTeijFb2BilSqV6sKNGLlVm+TGK6WW7s7iYYjGU7daOq/WqyXTI5myezEMTD71ecmV5JdeqprqXf3klT3ap6oI+gAAAAAAAAAAAAAAAAD5m1FNyeiS1bfQBlvTe3oiH7RbZ07SU7bFpVqy3Sqv+WHu62crazauV5KdljpuNst06q41Pd3ERA6VDO5GjkFfq6nOt7XKeqkuprqLBwm0thm6PoanIpV2tJUZ71L3dZVhlNppptNcGgLDy+w1rcN1cbV+7Te/0bWsH9URe82TzNrJ62rrQ6JUnqfeL2tyuPUKbqRuKS9irvfz4/qSK02/s5pK7s69OXS6bUl9GFQmeMyEXyZWVdP/AK2etHB5Su0qdjcN98NP1LAjtthJLV1qq7nSZ5Vtu8PBfw1cVX1Rp6froBwcdsJfVpKV9Whbw46R9eXy/cl1jjcVs5ayqR5NNaevWqvWT/8AdSIvf7fXFSLjj7SNH8dWXKa+BFr/ACN3kanpL24nVl0J8F8AiRbT7X1L9TtMbyqdtwlV4Sqdy6kaWD2qv8U405ydzbLc6U3viu59BwABcuJytplrdVrOpr0Si90ovqaN8pXHZC5xl1G4tKjjNcV0SXUy0tns7b5q09JT9SvDdVpN74v6rvA7AAAAAAAAAAAAADDILt1tC9ZYuynw/wCeSf5fMkm1GWWIxVStFr08/Uor8XX8CpJzlUnKdRuU5PVyfS2B8+7gAAoAAAAAAAAAAAAAG3i8hXxl7TurZ+tH+ZdEl1M1ABc+JyNHJ2NK6t36s1vX9L6UzdKw2HzLx2SVtWlpbXLSevsz6H9PkWeEAAAAAAAAAwa9/cK0sq9xLhSpufyQFcbd5F3uYdvB/wAK2XIX9z4kaS0PurVlWqzqzespycpPve8+AoAAAAAAAAAAAAAAAAAAM66b1xRbuy+R/wBTw1CvJ61UuRU/uRUJNfs1vGri6s5P1ZRVSK71uf0CJ+AAAAAAAAR/buu6OzVzGL0lVcaa+LWv+EyQHPzuLpZjHVLOtJx5TUozXsyXBgU2CWT2DyfLahcWsorg22vofPMPK9ta+J+QEVBKuYeV7a18T8hzDyvbWvifkFRUEq5h5XtrXxPyHMPK9ta+J+QEVBKuYeV7a18T8hzDyvbWvifkBFQSrmHle2tfE/Icw8r21r4n5ARUEq5h5XtrXxPyHMPK9ta+J+QRFQSrmHle2tfE/Icw8r21r4n5ARUEq5h5XtrXxPyHMPK9ta+J+QEVO1sbXdvtLZNvSM5Spvv1T0/zodDmHle2tfE/I6+zmxtSwv6d5f14TlSesIU+GunF6gTMAAAAAAAAcQAAAAAAAAAAAAAAAAAAAAAAAY03gAZAAAAAf//Z" alt="" className="object-cover w-full h-full" />

            )}
          </div>
        </div>
  
        <div className="">
          <label htmlFor="upload" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded cursor-pointer">
            Upload Image
          </label>
          <input type="file" id="upload" className="hidden" onChange={handleUpload} />
        </div>
      </div>
      <div class="flex flex-col w-1/2">
          <label for="username" class="font-medium">
            Username <span class="text-red-500">*</span>
          </label>
          <input
           type="text"
            id="username"
             value={username}
             onChange={(e)=> setUserName(e.target.value)}
             class="border border-gray-300 rounded-md px-3 py-1 h-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" required />
        </div>
  </div>
   
      <div class="flex flex-row space-x-4 w-full">
        <div class="flex flex-col w-1/2">
          <label for="email" class="font-medium">Email <span class="text-red-500">*</span></label>
          <input
          onChange={(e)=> setEmail(e.target.value)}
           type="text"
           id="email"
           value={email}
           
           class="border border-gray-300 rounded-md px-3 py-1 h-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
        </div>
        <div class="flex flex-col w-1/2">
          <label for="phone" class="font-medium">Phone</label>
          <input
           type="text"
           id="phone" 
           onChange={(e)=> setPhoneNo(e.target.value)}
           value={phoneNo} class="border border-gray-300 rounded-md px-3 py-1 h-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
        </div>
      
      </div>
  
      <div class="flex flex-row space-x-4 w-full">
      <div class="flex flex-col w-1/2">
          <label for="qualification" class="font-medium">Organization Name:</label>
          <input 
          type="text"
           id="qualification" 
           onChange={(e)=> setOrganizationName(e.target.value)}
           value={organizationName} class="border border-gray-300 rounded-md px-3 py-1 h-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
        </div>
        <div class="flex flex-col w-1/2">
          <label for="interest" class="font-medium">Organization Type:</label>
          <input 
          type="text"
           id="interest"
           onChange={(e)=> setOrganizationType(e.target.value)}
           value={organizationType} class="border border-gray-300 rounded-md px-3 py-1 h-10 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200" />
        </div>
      
      </div>
  
      <div className='flex flex-row space-x-4 w-full'>
      <div class="flex flex-col w-full">
          <label for="successStory" class="font-medium">Address:</label>
          <textarea
           id="successStory"
            value={address}
            onChange={(e)=> setAddress(e.target.value)}
             class="border border-gray-300 rounded-md px-3 py-1 h-20 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"></textarea>
        </div>
      </div>
      <div className='flex flex-row space-x-4 w-full'>
      <div class="flex flex-col w-full">
          <label for="successStory" class="font-medium">Additional Information:</label>
          <textarea
           id="successStory"
            value={additionalInfo}
            onChange={(e)=> setAdditionalInfo(e.target.value)}
             class="border border-gray-300 rounded-md px-3 py-1 h-20 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200"></textarea>
        </div>
      </div>
      <div class="flex justify-center mt-4">
        <button 
        type="submit" 
        onClick={onSubmit}
        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded cursor-pointer"
        >
  
          Submit
        </button>
      </div>
    </div>
  </div>
  
  )
}

export default ORGEditProfile
