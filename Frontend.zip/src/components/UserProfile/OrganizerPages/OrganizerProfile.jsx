import React ,  { useState ,   useEffect, useMemo} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


function OrganizerProfile() {


  


  return (
    <>

    </>
  )
}

export default OrganizerProfile
