import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faEnvelope ,faPhone , faHouse , faMagnifyingGlass , faMessage , faCalendar , faPortrait , faBars} from '@fortawesome/free-solid-svg-icons'


function PFMProfile() {

  const apiKey = import.meta.env.VITE_BASE_URL;
  
    const {id} = useParams()


    const storedData = localStorage.getItem('userInfo');
    const term = JSON.parse(storedData).id;
  
    // (term == id);
    // console.log("this is getting Profile : " , loginInfo)



    const navigate = useNavigate()


    const [selectedImage, setSelectedImage] = useState(null);

    const [userName ,setUserName] = useState()
    const [email ,setEmail] = useState()
    const [qualification ,setQualification] = useState()
    const [ interest , setInterest ] = useState()
    const [successStory , setSuccessStory] = useState()
    const [phoneNo , setPhoneNo] = useState()

    useEffect(()=>{

      const getUserById = async(id)=> {

        try{
          const result = await axios.get(`${apiKey}/performers/${id}`);
          
          // setTerm(result.data.performer.chooseTerm)
          setUserName(result.data.performer.username);
          setEmail(result.data.performer.email)
          setQualification(result.data.performer.qualification)
          setInterest(result.data.performer.interest)
          setSuccessStory(result.data.performer.successStory)
          setPhoneNo(result.data.performer.phoneNo)
           setSelectedImage(result.data.performer.image)     
     
        }catch(err){
          console.log(err);
        }
      }

      getUserById(id)
    },[id])

 
  return (
    <>
   <div className='card rounded-md shadow-md w-full  mx-auto'>

{/* Profile Header */}
<div className='profileHeader flex justify-evenly items-center gap-2 p-4'>
  {/* Profile Image */}
  <div className=' w-28 h-28 overflow-hidden rounded-full border border-gray-300 flex justify-center items-center'>
  <img src={selectedImage} alt="Selected" className="object-cover w-full h-full" />
  </div>

  {/* Profile Information */}
  <div className='flex  justify-end '>
    <div>

    <div className='mb-2'>
      <span className='text-xl font-semibold'>{userName}</span>
    </div>
    <div className='mb-2'>
      <span className='text-gray-600'> <FontAwesomeIcon icon={faEnvelope} /> {email}</span>
    </div>
    <div className='mb-2'>

      <span className='text-gray-600'> <FontAwesomeIcon icon={faPhone} /> {phoneNo}</span>
    </div>
{
  term == id && 
    <div className='flex justify-start'>
      <button onClick={() => navigate(`/pfm/profile/${id}/edit`)} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded cursor-pointer">
        Edit Profile
      </button>
    </div>
  }

</div>

  </div>
</div>
</div>


<div className='card  p-4 mt-4'>
  {/* Profile Content */}
  <div className="">
    {/* Success Story */}
 

    {/* Qualification */}
    <div className="mb-4  flex align-center">
      <div className='flex'>

      <h2 className="text-lg font-semibold mr-2 ">Qualification: </h2>
      </div>
      
      <div className='flex '>

      <p className="text-gray-700">{qualification}</p>
      </div>
    </div>

    {/* Interest */}
    <div className="mb-4 flex align-center">
      <div className='flex'>

      <h2 className="text-lg font-semibold mr-2">Interest: </h2>
      </div>
      <div className='flex'>

      <p className="text-gray-700">{interest}</p>
      </div>
    </div>


    <div className="mb-4">

    <div className='flex'>

<h2 className="text-lg font-semibold mr-2">Success Story: </h2>
</div>
      <p className="text-gray-700">{successStory}</p>
    </div>
  </div>
</div>

  </>

  )
}

export default PFMProfile
