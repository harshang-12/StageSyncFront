import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faPhone,faPaperPlane,faCalendar ,faClock, faMapMarkerAlt, faList ,faPen,faTrash , faHouse, faMagnifyingGlass, faMessage, faPortrait, faBars } from '@fortawesome/free-solid-svg-icons'
import axios from 'axios';
import moment from 'moment'


function ORGProfile() {

  const apiKey = import.meta.env.VITE_BASE_URL;

  const { id } = useParams()

  const storedData = localStorage.getItem('userInfo');
  const term = JSON.parse(storedData).id;


  const navigate = useNavigate()


  const [username, setUserName] = useState();
  const [email, setEmail] = useState();

  const [phoneNo, setPhoneNo] = useState();
  const [organizationName, setOrganizationName] = useState();
  const [organizationType, setOrganizationType] = useState();
  const [address, setAddress] = useState();
  const [additionalInfo, setAdditionalInfo] = useState();
  const [ imageUrl , setImageUrl ] = useState()


  const [schedleList, setSchedleList] = useState([]);

  console.log(schedleList);


  useEffect(() => {

    const getUserById = async (id) => {

      try {
        const result = await axios.get(`${apiKey}/organizers/${id}`);
        const data = result.data.organizer;


        console.log(result);
        setUserName(data.username);
        setEmail(data.email);
        setPhoneNo(data.phoneNo);
        setOrganizationName(data.organizationName);
        setOrganizationType(data.organizationType);
        setAddress(data.address);
        setAdditionalInfo(data.additionalInfo)
        setImageUrl(data.image)



        const UserSchedules = await axios.get(`${apiKey}/UsersOrganizerSchedule/${id}`);
        setSchedleList(UserSchedules.data.data.reverse())

      } catch (err) {
        console.log(err);
      }
    }

    getUserById(id)
  }, [id])



const deleteById= async(id)=> {

  try {
  const res = await axios.delete(`${apiKey}/organizerSchedule/${id}`)
  console.log(res)



  if(res){
    setSchedleList(schedleList.filter(i => i._id !== id))
  }
}
catch(err){
  console.log(err);
}
}



  return (
    <>
      <div className=' card '>

        {/* Profile Header */}
        <div className='profileHeader flex justify-evenly items-center gap-2 p-4'>
          {/* Profile Image */}
          <div className='flex'>
            <img src={imageUrl} alt="Profile" className='w-32 h-32 rounded-full border border-gray-300' />
          </div>

          {/* Profile Information */}
          <div className='flex  justify-end'>
            <div>

              <div className='mb-2'>
                <span className='text-2xl font-semibold'>{username}</span>
              </div>
              <div className='mb-2'>
                <span className='text-gray-600'> <FontAwesomeIcon icon={faEnvelope} /> {email}</span>
              </div>
              <div className='mb-2'>

                <span className='text-gray-600'> <FontAwesomeIcon icon={faPhone} /> {phoneNo}</span>
              </div>

              {
term === id && (

                <div className='flex justify-start'>
                <button onClick={() => navigate(`/org/profile/${id}/edit`)} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded cursor-pointer">
                  Edit Profile
                </button>
              </div>
)

              }
            </div>

          </div>
        </div>
      </div>


      <div className='card  p-4 mt-4'>

        <div className="">


          <div className="mb-4  flex align-center">
            <div className='flex'>

              <h2 className="text-md font-semibold mr-2 ">Organization Name : </h2>
            </div>

            <div className='flex '>

              <p className="text-gray-700">{organizationName}</p>
            </div>
          </div>

          <div className="mb-4 flex align-center">
            <div className='flex'>

              <h2 className="text-md font-semibold mr-2">Organization Type :</h2>
            </div>
            <div className='flex'>

              <p className="text-gray-700">{organizationType}</p>
            </div>
          </div>
          <div className="mb-4 flex align-center">
            <div className='flex'>

              <h2 className="text-md font-semibold mr-2">Address :</h2>
            </div>
            <div className='flex'>

              <p className="text-gray-700">{address}</p>
            </div>
          </div>
          <div className="mb-4 flex align-center">
            <div className='flex'>

              <h2 className="text-md font-semibold mr-2">Additional Information :</h2>
            </div>
            <div className='flex'>

              <p className="text-gray-700">{additionalInfo}</p>
            </div>
          </div>


        </div>
      </div>


      <div className='mt-4'>
        <span className='text-lg fw-bold'>Event Schedule :</span>
      </div>


<div className="container mt-2">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {schedleList.map(i => (
          <div key={i._id} className="mb-4">
            <div className="card  p-4">
              <div className="mb-2">
                <span className="text-xl font-bold">{i.eventName}</span>
              </div>
              <p className="text-sm mb-2">
                <FontAwesomeIcon icon={faMapMarkerAlt} className="mr-1" />
                {i.location}
              </p>
       {
        i.days !== 1 ?

          <p className="text-sm mb-2">
          <FontAwesomeIcon icon={faCalendar} />    {moment(i.eventStartDate).format('DD/MM/yyyy')} - {moment(i.eventEndDate).format('DD/MM/yyyy')}
          
          </p>
        :
        <p className="text-sm mb-2">
        <FontAwesomeIcon icon={faCalendar} />    {moment(i.eventStartDate).format('DD/MM/yyyy')} 
        
        </p>
              }
              <p className='text-sm mb-2'>
              <FontAwesomeIcon icon={faClock} />   {i.startTimePerDay} to {i.endTimePerDay}
              </p>
              <p className="text-sm mb-2">
            
            {i.description}
          </p>
          {
            term === id && (

         
              <div className='flex justify-end gap-2'>
                <button
                onClick={()=> navigate(`/org/editSchedule/${id}/${i._id}`)}
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-3 rounded">
                <FontAwesomeIcon icon={faPen} />
</button>

<button 
onClick={()=> deleteById(i._id)}
 class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-3 rounded">
<FontAwesomeIcon icon={faTrash} />
</button>
                </div>
                   )
                  }           
            </div>
          </div>
        ))}
      </div>
    </div>
    </>
  )
}

export default ORGProfile
