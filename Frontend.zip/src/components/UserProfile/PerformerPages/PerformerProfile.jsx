import React ,  { useState ,   useEffect, useMemo} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


function PerformerProfile() {

 

  


  return (
    <>


    </>
  )
}

export default PerformerProfile
