export const ValidName = new RegExp(
    '[a-zA-Z]'
); 
export const ValidBandName = new RegExp(
    '[a-zA-Z]'
); 

export const ValidUserName = new RegExp(
    '^[a-z0-9_-]{3,16}$'
)
export const ValidEmail =  /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ ; 